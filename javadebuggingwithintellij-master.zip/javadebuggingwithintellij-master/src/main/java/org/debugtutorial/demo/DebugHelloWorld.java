package org.debugtutorial.demo;

public class DebugHelloWorld
{
	public static void main(String[] args) {
		int i = 10;
		i = i + 100;
		System.out.println("Value of i:"+i);
 		i = i - 20;
		System.out.println("Value of i:"+i);
	}

}
